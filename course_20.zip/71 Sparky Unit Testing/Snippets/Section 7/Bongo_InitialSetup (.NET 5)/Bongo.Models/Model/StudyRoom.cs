﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bongo.Models.Model
{
    public class StudyRoom
    {
        public int Id { get; set; }
        public string RoomNumber { get; set; }
        public string RoomName { get; set; }
    }
}
